export default function ServiceFinderPage() {
  return (
    <main className="mx-auto max-w-4xl px-6 py-16">
      <p className="text-sm font-semibold uppercase tracking-wide text-cyan-600">Service Finder</p>
      <h1 className="mt-3 text-4xl font-bold tracking-tight">Find the right Maine Cyber Tech service path.</h1>
      <p className="mt-4 text-muted-foreground">Answer a few plain-English questions and get a recommended quick win, bundle, and monthly plan.</p>
      <button className="mt-6 rounded-xl bg-cyan-600 px-4 py-2 font-semibold text-white">Find My Best Fit</button>
    </main>
  );
}
