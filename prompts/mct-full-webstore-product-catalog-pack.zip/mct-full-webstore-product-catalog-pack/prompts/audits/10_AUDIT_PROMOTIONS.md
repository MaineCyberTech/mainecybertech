# 10 Audit Promotion Admin and Public Display

Audit the promotion admin center, public promo badges, eligibility logic, status handling, terms display, date handling, and audit log compatibility. Confirm no fake urgency or misleading discounts are present.


## Repository/style alignment
Inspect existing public and admin UI before coding. Match the current Maine Cyber Tech page style, spacing, typography, cards, rounded corners, colors, buttons, and responsive behavior.

## Mobile requirements
Everything must be usable on mobile. Use responsive cards, collapsible filters, accessible touch targets, and no horizontal overflow except intentional responsive tables.

## Safety requirements
Do not collect secrets. Do not use fake scarcity, fake countdowns, misleading discounts, or unsupported security/compliance guarantees.

## Required button / CTA
Each implementation must include one clear primary button and tests should locate it by role/name.

Suggested primary button: **Audit Promotions**


## Audit output format
Return findings as P0/P1/P2/P3 with file references, reproduction steps, recommended fix, and release impact.

